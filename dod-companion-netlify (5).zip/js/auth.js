// Authentication Module

let currentUser = null;

// Check if user is logged in
auth.onAuthStateChanged(async (user) => {
    console.log('Auth state changed:', user ? user.email : 'No user');
    
    if (user) {
        currentUser = user;
        await onUserLoggedIn(user);
    } else {
        currentUser = null;
        showLandingPage();
    }
});

// Show landing page
function showLandingPage() {
    document.getElementById('landingPage')?.classList.remove('hidden');
    document.getElementById('app')?.classList.add('hidden');
    document.getElementById('authModal')?.classList.remove('active');
}

// Hide landing page and show app
function showApp() {
    document.getElementById('landingPage')?.classList.add('hidden');
    document.getElementById('app')?.classList.remove('hidden');
    document.getElementById('authModal')?.classList.remove('active');
}

// Handle user logged in
async function onUserLoggedIn(user) {
    console.log('User logged in:', user.email);
    
    // Update UI with user info
    const userName = user.displayName || user.email.split('@')[0];
    const userNameEl = document.getElementById('userName');
    if (userNameEl) {
        userNameEl.textContent = userName;
    }
    
    // Check if user document exists, create if not
    try {
        const userDoc = await db.collection('users').doc(user.uid).get();
        if (!userDoc.exists) {
            await db.collection('users').doc(user.uid).set({
                email: user.email,
                displayName: userName,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            console.log('User document created');
        }
    } catch (error) {
        console.error('Error creating user document:', error);
    }
    
    showApp();
    loadDashboard();
}

// Auth tab switching
document.querySelectorAll('.auth-tab').forEach(btn => {
    btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        
        // Update tabs
        document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
        btn.classList.add('active');
        
        // Update forms
        document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
        if (tab === 'login') {
            document.getElementById('loginForm').classList.add('active');
        } else {
            document.getElementById('registerForm').classList.add('active');
        }
        
        // Clear error
        hideAuthError();
    });
});

// Login form
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    console.log('[Auth] Login attempt with email:', email);
    SuperDebug.logAuthAttempt('Email/Password', email);
    
    try {
        const result = await auth.signInWithEmailAndPassword(email, password);
        console.log('[Auth] Login successful');
        SuperDebug.logAuthSuccess(result.user);
    } catch (error) {
        console.error('[Auth] Login failed:', error);
        SuperDebug.logAuthError(error);
        showAuthError(getErrorMessage(error.code));
    }
});

// Register form
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    
    console.log('[Auth] Register attempt:', email);
    SuperDebug.logAuthAttempt('Registration', email);
    
    try {
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        console.log('[Auth] Registration successful');
        
        // Update display name
        await userCredential.user.updateProfile({
            displayName: username
        });
        
        SuperDebug.logAuthSuccess(userCredential.user);
    } catch (error) {
        console.error('[Auth] Registration failed:', error);
        SuperDebug.logAuthError(error);
        showAuthError(getErrorMessage(error.code));
    }
});

// Google Sign-In (både login och signup)
async function handleGoogleSignIn() {
    console.log('[Auth] Google sign-in initiated');
    SuperDebug.logAuthAttempt('Google Sign-In');
    
    try {
        // Use redirect instead of popup for better mobile support
        await auth.signInWithRedirect(googleProvider);
    } catch (error) {
        console.error('[Auth] Google sign-in error:', error);
        SuperDebug.logAuthError(error);
        showAuthError(getErrorMessage(error.code));
    }
}

// Handle redirect result (for Google sign-in)
auth.getRedirectResult().then((result) => {
    if (result && result.user) {
        console.log('[Auth] Google sign-in successful via redirect');
        SuperDebug.logAuthSuccess(result.user);
        // Auth state change will handle the rest
    }
}).catch((error) => {
    console.error('[Auth] Redirect result error:', error);
    if (error.code && error.code !== 'auth/popup-closed-by-user') {
        SuperDebug.logAuthError(error);
        showAuthError(getErrorMessage(error.code));
    }
});

document.getElementById('googleLoginBtn')?.addEventListener('click', handleGoogleSignIn);
document.getElementById('googleSignupBtn')?.addEventListener('click', handleGoogleSignIn);

// Logout
document.getElementById('logoutBtn').addEventListener('click', async () => {
    try {
        await auth.signOut();
    } catch (error) {
        console.error('Logout error:', error);
    }
});

// Show error message
function showAuthError(message) {
    const errorEl = document.getElementById('authError');
    errorEl.textContent = message;
    errorEl.classList.add('active');
}

// Hide error message
function hideAuthError() {
    const errorEl = document.getElementById('authError');
    errorEl.classList.remove('active');
}

// Get user-friendly error messages
function getErrorMessage(errorCode) {
    const messages = {
        'auth/email-already-in-use': 'E-postadressen används redan av ett annat konto.',
        'auth/invalid-email': 'Ogiltig e-postadress.',
        'auth/operation-not-allowed': 'Denna inloggningsmetod är inte aktiverad.',
        'auth/weak-password': 'Lösenordet är för svagt. Använd minst 6 tecken.',
        'auth/user-disabled': 'Detta konto har inaktiverats.',
        'auth/user-not-found': 'Ingen användare hittades med denna e-post.',
        'auth/wrong-password': 'Fel lösenord.',
        'auth/too-many-requests': 'För många försök. Försök igen senare.',
        'auth/popup-closed-by-user': 'Inloggningsfönstret stängdes.'
    };
    
    return messages[errorCode] || 'Ett fel uppstod. Försök igen.';
}

// Get current user
function getCurrentUser() {
    return currentUser;
}

// Check if user is logged in
function isUserLoggedIn() {
    return currentUser !== null;
}
