// Firebase Configuration
// Config från Firebase Console

const firebaseConfig = {
    apiKey: "AIzaSyAk1Vcc-hwIbrWRZQwofOAcH7e59u13WJM",
    authDomain: "drakar-demoner-companion.firebaseapp.com",
    projectId: "drakar-demoner-companion",
    storageBucket: "drakar-demoner-companion.firebasestorage.app",
    messagingSenderId: "730917516882",
    appId: "1:730917516882:web:85170f584c71fd4fac918b",
    measurementId: "G-SGETCW8J60"
};

// Initiera Firebase
firebase.initializeApp(firebaseConfig);

// Exportera Firebase-tjänster
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();

// Konfigurera Google Sign-In Provider
const googleProvider = new firebase.auth.GoogleAuthProvider();

console.log('✅ Firebase initialiserad med projekt:', firebaseConfig.projectId);
