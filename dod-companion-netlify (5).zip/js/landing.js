// Landing Page Logic

function scrollToFeatures() {
    document.getElementById('features').scrollIntoView({ behavior: 'smooth' });
}

// Handle all signup triggers
document.addEventListener('DOMContentLoaded', () => {
    // Signup button clicks
    document.querySelectorAll('.signup-trigger').forEach(btn => {
        btn.addEventListener('click', () => {
            showAuthModal('register');
        });
    });
    
    // Login button
    document.getElementById('loginBtn')?.addEventListener('click', () => {
        showAuthModal('login');
    });
    
    // Signup button in nav
    document.getElementById('signupBtn')?.addEventListener('click', () => {
        showAuthModal('register');
    });
});

function showAuthModal(tab = 'register') {
    const modal = document.getElementById('authModal');
    modal.classList.add('active');
    
    // Switch to correct tab
    document.querySelectorAll('.auth-tab').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.tab === tab) {
            btn.classList.add('active');
        }
    });
    
    document.querySelectorAll('.auth-form').forEach(form => {
        form.classList.remove('active');
    });
    
    if (tab === 'register') {
        document.getElementById('registerForm').classList.add('active');
    } else {
        document.getElementById('loginForm').classList.add('active');
    }
}

// Close modal
document.querySelector('#authModal .close-modal')?.addEventListener('click', () => {
    document.getElementById('authModal').classList.remove('active');
});

// Close on background click
document.getElementById('authModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'authModal') {
        document.getElementById('authModal').classList.remove('active');
    }
});
