// Campaign Service - Hantera kampanjer i Firebase

const CampaignService = {
    // Skapa ny kampanj
    async createCampaign(campaignData) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        const campaign = {
            ...campaignData,
            gameMasterId: user.uid,
            gameMasterName: user.displayName || user.email,
            playerIds: [],
            characterIds: [],
            adventureIds: [],
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        };
        
        const docRef = await db.collection('campaigns').add(campaign);
        return { id: docRef.id, ...campaign };
    },
    
    // Hämta kampanjer där användaren är SL
    async getGMCampaigns() {
        const user = getCurrentUser();
        if (!user) return [];
        
        const snapshot = await db.collection('campaigns')
            .where('gameMasterId', '==', user.uid)
            .orderBy('updatedAt', 'desc')
            .get();
        
        return snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
    },
    
    // Hämta kampanjer där användaren är spelare
    async getPlayerCampaigns() {
        const user = getCurrentUser();
        if (!user) return [];
        
        const snapshot = await db.collection('campaigns')
            .where('playerIds', 'array-contains', user.uid)
            .orderBy('updatedAt', 'desc')
            .get();
        
        return snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
    },
    
    // Hämta alla användarens kampanjer (som SL eller spelare)
    async getAllUserCampaigns() {
        const gmCampaigns = await this.getGMCampaigns();
        const playerCampaigns = await this.getPlayerCampaigns();
        
        // Kombinera och ta bort dubletter
        const allCampaigns = [...gmCampaigns, ...playerCampaigns];
        const uniqueCampaigns = allCampaigns.filter((campaign, index, self) =>
            index === self.findIndex(c => c.id === campaign.id)
        );
        
        return uniqueCampaigns;
    },
    
    // Hämta en specifik kampanj
    async getCampaign(campaignId) {
        const doc = await db.collection('campaigns').doc(campaignId).get();
        if (!doc.exists) throw new Error('Kampanj inte hittad');
        
        const campaign = { id: doc.id, ...doc.data() };
        
        // Kontrollera åtkomst
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        if (campaign.gameMasterId !== user.uid && 
            !campaign.playerIds.includes(user.uid)) {
            throw new Error('Du har inte åtkomst till denna kampanj');
        }
        
        return campaign;
    },
    
    // Uppdatera kampanj
    async updateCampaign(campaignId, updates) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Verifiera att användaren är SL
        const campaign = await this.getCampaign(campaignId);
        if (campaign.gameMasterId !== user.uid) {
            throw new Error('Endast SL kan uppdatera kampanjen');
        }
        
        await db.collection('campaigns').doc(campaignId).update({
            ...updates,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        return await this.getCampaign(campaignId);
    },
    
    // Ta bort kampanj
    async deleteCampaign(campaignId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Verifiera att användaren är SL
        const campaign = await this.getCampaign(campaignId);
        if (campaign.gameMasterId !== user.uid) {
            throw new Error('Endast SL kan ta bort kampanjen');
        }
        
        await db.collection('campaigns').doc(campaignId).delete();
    },
    
    // Bjud in spelare (via email)
    async invitePlayer(campaignId, playerEmail) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Verifiera att användaren är SL
        const campaign = await this.getCampaign(campaignId);
        if (campaign.gameMasterId !== user.uid) {
            throw new Error('Endast SL kan bjuda in spelare');
        }
        
        // Hitta spelare med denna email
        const userSnapshot = await db.collection('users')
            .where('email', '==', playerEmail)
            .get();
        
        if (userSnapshot.empty) {
            throw new Error('Användare inte hittad');
        }
        
        const playerId = userSnapshot.docs[0].id;
        
        // Lägg till spelare
        await db.collection('campaigns').doc(campaignId).update({
            playerIds: firebase.firestore.FieldValue.arrayUnion(playerId),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        // Skapa notifikation för spelaren (valfritt)
        await db.collection('notifications').add({
            userId: playerId,
            type: 'campaign_invite',
            campaignId: campaignId,
            campaignName: campaign.name,
            from: user.displayName || user.email,
            read: false,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    },
    
    // Ta bort spelare
    async removePlayer(campaignId, playerId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Verifiera att användaren är SL
        const campaign = await this.getCampaign(campaignId);
        if (campaign.gameMasterId !== user.uid) {
            throw new Error('Endast SL kan ta bort spelare');
        }
        
        await db.collection('campaigns').doc(campaignId).update({
            playerIds: firebase.firestore.FieldValue.arrayRemove(playerId),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    },
    
    // Lägg till karaktär i kampanj
    async addCharacter(campaignId, characterId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Kontrollera att användaren har åtkomst till kampanjen
        const campaign = await this.getCampaign(campaignId);
        
        // Verifiera att användaren äger karaktären
        const character = await CharacterService.getCharacter(characterId);
        if (character.ownerId !== user.uid) {
            throw new Error('Du äger inte denna karaktär');
        }
        
        // Lägg till karaktär i kampanj
        await db.collection('campaigns').doc(campaignId).update({
            characterIds: firebase.firestore.FieldValue.arrayUnion(characterId),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        // Uppdatera karaktären med kampanj-ID
        await CharacterService.shareWithCampaign(characterId, campaignId);
    },
    
    // Ta bort karaktär från kampanj
    async removeCharacter(campaignId, characterId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        const campaign = await this.getCampaign(campaignId);
        
        // Verifiera behörighet (SL eller karaktärens ägare)
        const character = await CharacterService.getCharacter(characterId);
        if (campaign.gameMasterId !== user.uid && character.ownerId !== user.uid) {
            throw new Error('Du har inte behörighet');
        }
        
        await db.collection('campaigns').doc(campaignId).update({
            characterIds: firebase.firestore.FieldValue.arrayRemove(characterId),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        // Ta bort kampanj-ID från karaktären
        await CharacterService.updateCharacter(characterId, { campaignId: null });
    },
    
    // Lägg till äventyr i kampanj
    async addAdventure(campaignId, adventureId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Verifiera att användaren är SL
        const campaign = await this.getCampaign(campaignId);
        if (campaign.gameMasterId !== user.uid) {
            throw new Error('Endast SL kan lägga till äventyr');
        }
        
        await db.collection('campaigns').doc(campaignId).update({
            adventureIds: firebase.firestore.FieldValue.arrayUnion(adventureId),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    }
};
