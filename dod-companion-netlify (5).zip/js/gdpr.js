// GDPR Cookie Consent

const GDPR = {
    init() {
        // Check if user has already consented
        const consent = localStorage.getItem('gdpr_consent');
        
        if (!consent) {
            this.showBanner();
        }
    },
    
    showBanner() {
        const banner = document.createElement('div');
        banner.className = 'gdpr-banner active';
        banner.innerHTML = `
            <div class="gdpr-content">
                <div class="gdpr-text">
                    <h3>🍪 Vi använder cookies</h3>
                    <p>
                        Denna webbplats använder Firebase Authentication och Firestore för att hantera ditt konto och spara dina karaktärer. 
                        Vi samlar endast in den data som behövs för att leverera tjänsten (email, användarnamn, och speldata).
                        <a href="#" onclick="GDPR.showPrivacyPolicy(); return false;">Läs mer om dataskydd</a>
                    </p>
                </div>
                <div class="gdpr-actions">
                    <button class="btn btn-outline" onclick="GDPR.showPrivacyPolicy()">
                        Läs mer
                    </button>
                    <button class="btn btn-gold" onclick="GDPR.acceptAll()">
                        Acceptera alla
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(banner);
    },
    
    acceptAll() {
        localStorage.setItem('gdpr_consent', 'all');
        localStorage.setItem('gdpr_consent_date', new Date().toISOString());
        
        const banner = document.querySelector('.gdpr-banner');
        if (banner) {
            banner.style.opacity = '0';
            setTimeout(() => banner.remove(), 300);
        }
        
        console.log('[GDPR] User accepted all cookies');
    },
    
    showPrivacyPolicy() {
        const modal = document.createElement('div');
        modal.className = 'privacy-modal active';
        modal.innerHTML = `
            <div class="privacy-content">
                <h2>Integritetspolicy</h2>
                
                <h3>Vilken data samlar vi in?</h3>
                <p>Vi samlar endast in data som är nödvändig för att leverera tjänsten:</p>
                <ul>
                    <li><strong>Kontouppgifter:</strong> E-postadress och användarnamn (om du registrerar ett konto)</li>
                    <li><strong>Speldata:</strong> Karaktärer, äventyr och kampanjer som du skapar</li>
                    <li><strong>Autentiseringsdata:</strong> Hanteras av Google Firebase Authentication</li>
                </ul>
                
                <h3>Hur används din data?</h3>
                <ul>
                    <li>För att autentisera ditt konto och hålla dig inloggad</li>
                    <li>För att spara och synkronisera dina karaktärer och äventyr</li>
                    <li>För att möjliggöra delning av äventyr med andra användare</li>
                </ul>
                
                <h3>Var lagras din data?</h3>
                <p>All data lagras säkert i Google Firebase (Google Cloud Platform) inom EU-regionen.</p>
                
                <h3>Cookies och lokal lagring</h3>
                <p>Vi använder:</p>
                <ul>
                    <li><strong>Firebase Authentication cookies:</strong> För att hålla dig inloggad</li>
                    <li><strong>LocalStorage:</strong> För att spara dina GDPR-preferenser</li>
                </ul>
                
                <h3>Dina rättigheter</h3>
                <p>Du har rätt att:</p>
                <ul>
                    <li>Få tillgång till din data</li>
                    <li>Radera ditt konto och all tillhörande data</li>
                    <li>Exportera din data</li>
                    <li>Återkalla ditt samtycke när som helst</li>
                </ul>
                
                <h3>Tredjepartstjänster</h3>
                <p>Vi använder följande tredjepartstjänster:</p>
                <ul>
                    <li><strong>Google Firebase:</strong> För autentisering och datalagring</li>
                    <li><strong>Netlify:</strong> För webbhosting</li>
                </ul>
                <p>Dessa tjänster har sina egna integritetspolicies:</p>
                <ul>
                    <li><a href="https://firebase.google.com/support/privacy" target="_blank">Firebase Privacy Policy</a></li>
                    <li><a href="https://www.netlify.com/privacy/" target="_blank">Netlify Privacy Policy</a></li>
                </ul>
                
                <h3>Kontakt</h3>
                <p>För frågor om din data eller denna policy, kontakta oss via GitHub.</p>
                
                <p style="margin-top: 2rem; color: var(--text-muted); font-size: 0.875rem;">
                    Senast uppdaterad: Januari 2025
                </p>
                
                <button class="btn btn-gold btn-large" style="width: 100%; margin-top: 2rem;" 
                        onclick="this.closest('.privacy-modal').remove()">
                    Stäng
                </button>
            </div>
        `;
        document.body.appendChild(modal);
        
        // Close on background click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }
};

// Initialize GDPR on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => GDPR.init());
} else {
    GDPR.init();
}

// Export for external use
window.GDPR = GDPR;
