// ============================================================================
// DRAKAR OCH DEMONER 2023 - CHARACTER CREATOR
// En steg-för-steg karaktärsskapare inspirerad av D&D Beyond
// ============================================================================

// === GAME DATA (DoD 2023 Fria Ligan) ===

const DOD_DATA = {
    // Släkten med förmågor och modifikationer
    kin: {
        manniska: {
            name: 'Människa',
            description: 'Människor är det vanligaste släktet i Altor. De är anpassningsbara och ambitiösa, och kan bli vad som helst.',
            ability: {
                name: 'Anpassningsbar',
                description: 'Du kan använda en annan grundegenskap än den som normalt används för ett färdighetsslag, en gång per vilofas.',
                cost: '1 VP'
            },
            baseMovement: 10,
            modifiers: {},
            languages: ['Allmänspråket']
        },
        alv: {
            name: 'Alv',
            description: 'Alver är ett gammalt och mystiskt folk som lever i harmoni med naturen. De är kända för sin skönhet och visdom.',
            ability: {
                name: 'Inre frid',
                description: 'När du vilar återfår du alla förlorade VP och KP, inte bara hälften.',
                cost: 'Passiv'
            },
            baseMovement: 10,
            modifiers: { SMI: 2, INT: 2, STY: -2, FYS: -2 },
            languages: ['Allmänspråket', 'Alviska']
        },
        dvarg: {
            name: 'Dvärg',
            description: 'Dvärgar är ett stolt och sturigt folk som lever i bergssalar. De är mästare på hantverk och gruvdrift.',
            ability: {
                name: 'Långsint',
                description: 'Du får fördel på attacker mot en fiende som skadat dig sedan din senaste vila.',
                cost: 'Passiv'
            },
            baseMovement: 8,
            modifiers: { STY: 2, FYS: 2, SMI: -2, KAR: -2 },
            languages: ['Allmänspråket', 'Dvärgiska']
        },
        halvling: {
            name: 'Halvling',
            description: 'Halvlingar är små och kvicka varelser med stort hjärta. De älskar mat, musik och bekvämlighet.',
            ability: {
                name: 'Svårträffad',
                description: 'Du får fördel på Undvika-slag mot varelser större än dig själv.',
                cost: 'Passiv'
            },
            baseMovement: 8,
            modifiers: { SMI: 2, KAR: 2, STY: -2, FYS: -2 },
            languages: ['Allmänspråket', 'Halvlingska']
        },
        anka: {
            name: 'Anka',
            description: 'Ankorna är ett stolt krigarfolk med fjädrar och näbbar. De är kända för sitt heta temperament.',
            ability: {
                name: 'Simmare',
                description: 'Du kan simma lika snabbt som du springer och kan hålla andan i INT minuter.',
                cost: 'Passiv'
            },
            secondAbility: {
                name: 'Ilsken',
                description: 'När du blir arg får du fördel på ditt nästa slag. Du kan bli arg som en fri aktion.',
                cost: '3 VP'
            },
            baseMovement: 10,
            modifiers: { FYS: 2, INT: -2 },
            languages: ['Allmänspråket', 'Ankspråket']
        },
        vargfolk: {
            name: 'Vargfolk',
            description: 'Vargfolket är vilda och lojala varelser med vassa sinnen. De lever ofta i klaner i vildmarken.',
            ability: {
                name: 'Jaktinstinkt',
                description: 'Du får fördel på Upptäcka fara och kan spåra bytesdjur med doft.',
                cost: 'Passiv'
            },
            baseMovement: 12,
            modifiers: { SMI: 2, FYS: 2, INT: -2, KAR: -2 },
            languages: ['Allmänspråket', 'Vargtunga']
        }
    },

    // Yrken med förmågor och färdigheter
    professions: {
        bard: {
            name: 'Bard',
            description: 'Barder är berättare, musiker och underhållare som reser världen runt för att samla historier och sprida glädje.',
            keyAttribute: 'KAR',
            heroicAbility: {
                name: 'Tonkonst',
                description: 'Du kan spela musik som ger dina allierade fördel på sina slag eller ger fiender nackdel.',
                cost: '2 VP'
            },
            skills: ['Underhålla', 'Bluffa', 'Övertala', 'Kulturkännedom', 'Läkekonst', 'Smyga'],
            equipment: [
                { roll: '1-2', items: ['Kniv', 'Luta', 'Ryggsäck', 'Mat (3 rationer)', 'Fackla (3 st)'] },
                { roll: '3-4', items: ['Kortsvärd', 'Flöjt', 'Ryggsäck', 'Mat (3 rationer)', 'Rep (10m)'] },
                { roll: '5-6', items: ['Stav', 'Trumma', 'Ryggsäck', 'Mat (3 rationer)', 'Elddon'] }
            ]
        },
        hantverkare: {
            name: 'Hantverkare',
            description: 'Hantverkare är skickliga yrkesmän som skapar och reparerar allt från vapen till smycken.',
            keyAttribute: 'INT',
            heroicAbility: {
                name: 'Mästerverk',
                description: 'Du kan skapa eller reparera föremål av exceptionell kvalitet under en vila.',
                cost: '3 VP'
            },
            skills: ['Hantverk', 'Värdesätta', 'Köpslå', 'Fingerfärdighet', 'Kulturkännedom', 'Slagsmål'],
            equipment: [
                { roll: '1-2', items: ['Hammare', 'Hantverksverktyg', 'Ryggsäck', 'Mat (3 rationer)', 'Ljus (5 st)'] },
                { roll: '3-4', items: ['Yxa', 'Hantverksverktyg', 'Ryggsäck', 'Mat (3 rationer)', 'Rep (10m)'] },
                { roll: '5-6', items: ['Kniv', 'Hantverksverktyg', 'Ryggsäck', 'Mat (3 rationer)', 'Elddon'] }
            ]
        },
        jagare: {
            name: 'Jägare',
            description: 'Jägare är vildmarkens mästare, skickliga på att spåra, jaga och överleva i naturen.',
            keyAttribute: 'SMI',
            heroicAbility: {
                name: 'Dödligt sikte',
                description: 'Du kan sikta noggrant för att göra extra skada med avståndsvapen.',
                cost: '2 VP'
            },
            skills: ['Skytte', 'Smyga', 'Vildmarksvana', 'Upptäcka fara', 'Hantera djur', 'Kniv'],
            equipment: [
                { roll: '1-2', items: ['Kort båge', 'Pilar (20 st)', 'Kniv', 'Ryggsäck', 'Mat (3 rationer)'] },
                { roll: '3-4', items: ['Spjut', 'Kniv', 'Ryggsäck', 'Mat (3 rationer)', 'Snara'] },
                { roll: '5-6', items: ['Armborst', 'Bult (10 st)', 'Kniv', 'Ryggsäck', 'Mat (3 rationer)'] }
            ]
        },
        krigare: {
            name: 'Krigare',
            description: 'Krigare är mästare på strid och vapenkunnighet. De lever för att kämpa och skydda.',
            keyAttribute: 'STY',
            heroicAbility: {
                name: 'Vapenmästare',
                description: 'Du kan använda vilket närstridsvapen som helst utan nackdel, oavsett träning.',
                cost: 'Passiv'
            },
            skills: ['Svärd', 'Spjut', 'Sköld', 'Yxa', 'Krossvapen', 'Undvika'],
            equipment: [
                { roll: '1-2', items: ['Svärd', 'Sköld', 'Läderrustning', 'Ryggsäck', 'Mat (3 rationer)'] },
                { roll: '3-4', items: ['Yxa', 'Sköld', 'Läderrustning', 'Ryggsäck', 'Mat (3 rationer)'] },
                { roll: '5-6', items: ['Tvåhandssvärd', 'Läderrustning', 'Ryggsäck', 'Mat (3 rationer)', 'Elddon'] }
            ]
        },
        lard: {
            name: 'Lärd',
            description: 'Lärda är forskare och kunskapssökare som ägnar sina liv åt att förstå världens mysterier.',
            keyAttribute: 'INT',
            heroicAbility: {
                name: 'Encyklopedisk kunskap',
                description: 'Du kan slå på en kunskapsfärdighet du inte är tränad i utan nackdel.',
                cost: '1 VP'
            },
            skills: ['Kulturkännedom', 'Språkkännedom', 'Läkekonst', 'Botanik', 'Zoologi', 'Övertala'],
            equipment: [
                { roll: '1-2', items: ['Stav', 'Bok', 'Skrivdon', 'Ryggsäck', 'Mat (3 rationer)'] },
                { roll: '3-4', items: ['Kniv', 'Bok (2 st)', 'Skrivdon', 'Ryggsäck', 'Mat (3 rationer)'] },
                { roll: '5-6', items: ['Stav', 'Förstoringsglas', 'Skrivdon', 'Ryggsäck', 'Mat (3 rationer)'] }
            ]
        },
        magiker: {
            name: 'Magiker',
            description: 'Magiker har lärt sig att kanalisera mystiska krafter för att böja verkligheten efter sin vilja.',
            keyAttribute: 'INT',
            heroicAbility: {
                name: 'Magi',
                description: 'Du kan använda besvärjelser från din magiskola. Välj en magiskola vid start.',
                cost: 'Varierar'
            },
            isMage: true,
            magicSchools: ['Elementalism', 'Mentalism', 'Animism'],
            skills: ['Magiskola', 'Kulturkännedom', 'Språkkännedom', 'Finna dolda ting', 'Övertala', 'Stav'],
            equipment: [
                { roll: '1-2', items: ['Stav', 'Magisk fokus', 'Ryggsäck', 'Mat (3 rationer)', 'Ljus (5 st)'] },
                { roll: '3-4', items: ['Kniv', 'Magisk fokus', 'Ryggsäck', 'Mat (3 rationer)', 'Elddon'] },
                { roll: '5-6', items: ['Magisk fokus', 'Bok', 'Ryggsäck', 'Mat (3 rationer)', 'Ljus (5 st)'] }
            ]
        },
        nasare: {
            name: 'Nasare',
            description: 'Nasare är handlare, förhandlare och ibland lycksökare som lever på sin charm och sina kontakter.',
            keyAttribute: 'KAR',
            heroicAbility: {
                name: 'Guldnäsa',
                description: 'Du kan hitta värdefulla föremål eller information genom dina kontakter.',
                cost: '2 VP'
            },
            skills: ['Köpslå', 'Värdesätta', 'Övertala', 'Bluffa', 'Kulturkännedom', 'Upptäcka fara'],
            equipment: [
                { roll: '1-2', items: ['Kniv', 'Våg', 'Ryggsäck', 'Mat (3 rationer)', 'Mynt (3T6 silver)'] },
                { roll: '3-4', items: ['Kort svärd', 'Handelsbrev', 'Ryggsäck', 'Mat (3 rationer)', 'Mynt (2T6 silver)'] },
                { roll: '5-6', items: ['Kniv', 'Kartor', 'Ryggsäck', 'Mat (3 rationer)', 'Mynt (4T6 silver)'] }
            ]
        },
        riddare: {
            name: 'Riddare',
            description: 'Riddare är ädla krigare som följer en hederskodex. De kämpar för ära, lov och sina ideal.',
            keyAttribute: 'STY',
            heroicAbility: {
                name: 'Stridsrop',
                description: 'Du kan utstöta ett stridsrop som ger fiender nackdel på deras nästa slag.',
                cost: '2 VP'
            },
            skills: ['Svärd', 'Spjut', 'Sköld', 'Rida', 'Kulturkännedom', 'Övertala'],
            equipment: [
                { roll: '1-2', items: ['Svärd', 'Sköld', 'Ringbrynja', 'Ryggsäck', 'Mat (3 rationer)'] },
                { roll: '3-4', items: ['Lans', 'Sköld', 'Ringbrynja', 'Ryggsäck', 'Mat (3 rationer)'] },
                { roll: '5-6', items: ['Slagsvärd', 'Ringbrynja', 'Ryggsäck', 'Mat (3 rationer)', 'Vapen-olja'] }
            ]
        },
        sjofarare: {
            name: 'Sjöfarare',
            description: 'Sjöfarare är havets barn, vana vid livet på skepp och de faror som lurar på öppet vatten.',
            keyAttribute: 'SMI',
            heroicAbility: {
                name: 'Saltvatten i blodet',
                description: 'Du får fördel på alla slag relaterade till skepp, navigation och simning.',
                cost: 'Passiv'
            },
            skills: ['Sjökunnighet', 'Simma', 'Kniv', 'Akrobatik', 'Svärd', 'Upptäcka fara'],
            equipment: [
                { roll: '1-2', items: ['Kortsvärd', 'Kniv', 'Ryggsäck', 'Mat (3 rationer)', 'Rep (10m)'] },
                { roll: '3-4', items: ['Sabel', 'Kniv', 'Ryggsäck', 'Mat (3 rationer)', 'Kompass'] },
                { roll: '5-6', items: ['Yxa', 'Kniv', 'Ryggsäck', 'Mat (3 rationer)', 'Kikare'] }
            ]
        },
        tjuv: {
            name: 'Tjuv',
            description: 'Tjuvar lever i skuggorna, mästare på att ta det som andra har och försvinna utan spår.',
            keyAttribute: 'SMI',
            heroicAbility: {
                name: 'Tjuvhugg',
                description: 'Du gör extra skada när du anfaller en fiende som inte är medveten om dig.',
                cost: '2 VP'
            },
            skills: ['Smyga', 'Fingerfärdighet', 'Finna dolda ting', 'Akrobatik', 'Kniv', 'Bluffa'],
            equipment: [
                { roll: '1-2', items: ['Kniv (2 st)', 'Dyrkar', 'Ryggsäck', 'Mat (3 rationer)', 'Rep (10m)'] },
                { roll: '3-4', items: ['Kortsvärd', 'Dyrkar', 'Ryggsäck', 'Mat (3 rationer)', 'Kattfot'] },
                { roll: '5-6', items: ['Kniv', 'Armborst', 'Bult (10 st)', 'Ryggsäck', 'Mat (3 rationer)'] }
            ]
        }
    },

    // Ålderskategorier
    ages: {
        ung: {
            name: 'Ung',
            description: 'Du är i livets vår, full av energi men saknar erfarenhet.',
            modifiers: { STY: -1, FYS: 0, SMI: 1, INT: 0, PSY: -1 },
            trainedSkills: 4
        },
        medelalders: {
            name: 'Medelålders',
            description: 'Du är i din bästa ålder, med en bra balans mellan kropp och sinne.',
            modifiers: { STY: 0, FYS: 0, SMI: 0, INT: 0, PSY: 0 },
            trainedSkills: 6
        },
        gammal: {
            name: 'Gammal',
            description: 'Åren har gett dig visdom, men kroppen är inte vad den en gång var.',
            modifiers: { STY: -1, FYS: -1, SMI: -1, INT: 1, PSY: 1 },
            trainedSkills: 8
        }
    },

    // Grundegenskaper
    attributes: ['STY', 'FYS', 'SMI', 'INT', 'PSY'],
    
    attributeNames: {
        STY: 'Styrka',
        FYS: 'Fysik', 
        SMI: 'Smidighet',
        INT: 'Intelligens',
        PSY: 'Psyke'
    },

    attributeDescriptions: {
        STY: 'Fysisk kraft och muskelstyrka',
        FYS: 'Uthållighet och motståndskraft',
        SMI: 'Snabbhet, balans och koordination',
        INT: 'Logik, minne och kunskap',
        PSY: 'Viljestyrka och mental fokus'
    }
};

// === CHARACTER STATE ===
let currentCharacter = {
    step: 1,
    name: '',
    kin: null,
    profession: null,
    age: null,
    attributes: { STY: 10, FYS: 10, SMI: 10, INT: 10, PSY: 10 },
    baseAttributes: { STY: 10, FYS: 10, SMI: 10, INT: 10, PSY: 10 },
    rolledAttributes: [],
    trainedSkills: [],
    equipment: [],
    equipmentRoll: null,
    magicSchool: null,
    appearance: {
        portrait: null
    }
};

// === WIZARD STEPS ===
const STEPS = [
    { id: 1, name: 'Namn', icon: '✏️' },
    { id: 2, name: 'Släkte', icon: '👤' },
    { id: 3, name: 'Yrke', icon: '⚔️' },
    { id: 4, name: 'Ålder', icon: '⏳' },
    { id: 5, name: 'Egenskaper', icon: '🎲' },
    { id: 6, name: 'Utrustning', icon: '🎒' },
    { id: 7, name: 'Slutför', icon: '✨' }
];

// === MAIN FUNCTIONS ===

function showCharacterCreator() {
    const modal = document.getElementById('characterCreatorModal');
    const container = document.getElementById('characterCreator');
    
    // Reset character
    currentCharacter = {
        step: 1,
        name: '',
        kin: null,
        profession: null,
        age: null,
        attributes: { STY: 10, FYS: 10, SMI: 10, INT: 10, PSY: 10 },
        baseAttributes: { STY: 10, FYS: 10, SMI: 10, INT: 10, PSY: 10 },
        rolledAttributes: [],
        trainedSkills: [],
        equipment: [],
        equipmentRoll: null,
        magicSchool: null,
        appearance: { portrait: null }
    };
    
    renderWizard(container);
    modal.classList.add('active');
}

function renderWizard(container) {
    container.innerHTML = `
        <div class="cc-wizard">
            <!-- Progress Header -->
            <div class="cc-header">
                <div class="cc-character-preview">
                    <div class="cc-portrait" id="ccPortrait">
                        <span class="cc-portrait-placeholder">?</span>
                    </div>
                    <div class="cc-name-display">
                        <input type="text" 
                               id="ccNameInput" 
                               class="cc-name-input" 
                               placeholder="Namnlös hjälte..."
                               value="${currentCharacter.name}"
                               oninput="updateCharacterName(this.value)">
                        <div class="cc-subtitle" id="ccSubtitle">Välj ditt öde</div>
                    </div>
                </div>
                <div class="cc-progress">
                    ${STEPS.map(step => `
                        <div class="cc-step ${step.id === currentCharacter.step ? 'active' : ''} ${step.id < currentCharacter.step ? 'completed' : ''}" 
                             data-step="${step.id}"
                             onclick="goToStep(${step.id})">
                            <span class="cc-step-icon">${step.id < currentCharacter.step ? '✓' : step.icon}</span>
                            <span class="cc-step-name">${step.name}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <!-- Navigation Arrows -->
            <button class="cc-nav-arrow cc-nav-prev ${currentCharacter.step === 1 ? 'disabled' : ''}" 
                    onclick="prevStep()" ${currentCharacter.step === 1 ? 'disabled' : ''}>
                ❮
            </button>
            <button class="cc-nav-arrow cc-nav-next ${!canProceed() ? 'disabled' : ''}" 
                    onclick="nextStep()" ${!canProceed() ? 'disabled' : ''}>
                ❯
            </button>
            
            <!-- Step Content -->
            <div class="cc-content" id="ccContent">
                ${renderStepContent()}
            </div>
        </div>
    `;
    
    updatePreview();
}

function renderStepContent() {
    switch(currentCharacter.step) {
        case 1: return renderNameStep();
        case 2: return renderKinStep();
        case 3: return renderProfessionStep();
        case 4: return renderAgeStep();
        case 5: return renderAttributesStep();
        case 6: return renderEquipmentStep();
        case 7: return renderSummaryStep();
        default: return '';
    }
}

// === STEP 1: NAME ===
function renderNameStep() {
    return `
        <div class="cc-step-content cc-name-step animate-in">
            <h2 class="cc-title">Vad heter din hjälte?</h2>
            <p class="cc-description">Varje legend börjar med ett namn. Vad kommer barderna att sjunga om?</p>
            
            <div class="cc-name-input-large">
                <input type="text" 
                       id="ccNameLarge" 
                       class="cc-input-hero"
                       placeholder="Skriv ditt namn..."
                       value="${currentCharacter.name}"
                       oninput="updateCharacterName(this.value)"
                       autofocus>
            </div>
            
            <div class="cc-name-suggestions">
                <p class="cc-suggestion-label">Behöver du inspiration?</p>
                <div class="cc-suggestion-buttons">
                    <button class="cc-suggestion-btn" onclick="suggestName('male')">🎲 Mansnamn</button>
                    <button class="cc-suggestion-btn" onclick="suggestName('female')">🎲 Kvinnonamn</button>
                    <button class="cc-suggestion-btn" onclick="suggestName('neutral')">🎲 Könlöst</button>
                </div>
            </div>
        </div>
    `;
}

function updateCharacterName(name) {
    currentCharacter.name = name;
    
    // Update both name inputs
    const headerInput = document.getElementById('ccNameInput');
    const largeInput = document.getElementById('ccNameLarge');
    
    if (headerInput && headerInput.value !== name) headerInput.value = name;
    if (largeInput && largeInput.value !== name) largeInput.value = name;
    
    updateNavigation();
}

function suggestName(type) {
    const names = {
        male: ['Thorvald', 'Grimnar', 'Aldric', 'Bjorn', 'Fenris', 'Ragnar', 'Sigurd', 'Valdric', 'Eirik', 'Gunnar'],
        female: ['Astrid', 'Freya', 'Sigrid', 'Ylva', 'Ingrid', 'Brunhild', 'Solveig', 'Ragnhild', 'Thyra', 'Eira'],
        neutral: ['Raven', 'Storm', 'Aspen', 'Sage', 'River', 'Ash', 'Frost', 'Dawn', 'Vale', 'Wren']
    };
    
    const nameList = names[type];
    const randomName = nameList[Math.floor(Math.random() * nameList.length)];
    
    // Animate the name change
    const input = document.getElementById('ccNameLarge');
    if (input) {
        input.classList.add('name-flash');
        setTimeout(() => input.classList.remove('name-flash'), 300);
    }
    
    updateCharacterName(randomName);
}

// === STEP 2: KIN (SLÄKTE) ===
function renderKinStep() {
    return `
        <div class="cc-step-content cc-kin-step animate-in">
            <h2 class="cc-title">Välj ditt släkte</h2>
            <p class="cc-description">Ditt ursprung formar vem du är. Välj det folk du tillhör.</p>
            
            <div class="cc-card-grid">
                ${Object.entries(DOD_DATA.kin).map(([key, kin]) => `
                    <div class="cc-card cc-kin-card ${currentCharacter.kin === key ? 'selected' : ''}" 
                         onclick="selectKin('${key}')">
                        <div class="cc-card-icon">${getKinIcon(key)}</div>
                        <h3 class="cc-card-title">${kin.name}</h3>
                        <p class="cc-card-description">${kin.description}</p>
                        <div class="cc-card-ability">
                            <span class="cc-ability-label">Förmåga:</span>
                            <span class="cc-ability-name">${kin.ability.name}</span>
                        </div>
                        ${kin.secondAbility ? `
                            <div class="cc-card-ability">
                                <span class="cc-ability-label">Bonus:</span>
                                <span class="cc-ability-name">${kin.secondAbility.name}</span>
                            </div>
                        ` : ''}
                        <div class="cc-card-check">✓</div>
                    </div>
                `).join('')}
            </div>
            
            ${currentCharacter.kin ? renderKinDetails(currentCharacter.kin) : ''}
        </div>
    `;
}

function getKinIcon(kin) {
    const icons = {
        manniska: '👤',
        alv: '🧝',
        dvarg: '🪓',
        halvling: '🍀',
        anka: '🦆',
        vargfolk: '🐺'
    };
    return icons[kin] || '👤';
}

function selectKin(kinKey) {
    currentCharacter.kin = kinKey;
    
    // Apply kin modifiers to base attributes
    recalculateAttributes();
    
    // Re-render with animation
    const content = document.getElementById('ccContent');
    content.innerHTML = renderKinStep();
    
    updatePreview();
    updateNavigation();
}

function renderKinDetails(kinKey) {
    const kin = DOD_DATA.kin[kinKey];
    
    return `
        <div class="cc-details-panel animate-in">
            <h3>${kin.name}</h3>
            
            <div class="cc-detail-section">
                <h4>Släktesförmåga: ${kin.ability.name}</h4>
                <p>${kin.ability.description}</p>
                <span class="cc-cost-badge">${kin.ability.cost}</span>
            </div>
            
            ${kin.secondAbility ? `
                <div class="cc-detail-section">
                    <h4>Bonusförmåga: ${kin.secondAbility.name}</h4>
                    <p>${kin.secondAbility.description}</p>
                    <span class="cc-cost-badge">${kin.secondAbility.cost}</span>
                </div>
            ` : ''}
            
            <div class="cc-detail-section">
                <h4>Modifikationer</h4>
                <div class="cc-modifiers">
                    ${Object.entries(kin.modifiers).length > 0 ? 
                        Object.entries(kin.modifiers).map(([attr, mod]) => `
                            <span class="cc-modifier ${mod > 0 ? 'positive' : 'negative'}">
                                ${DOD_DATA.attributeNames[attr]}: ${mod > 0 ? '+' : ''}${mod}
                            </span>
                        `).join('') : 
                        '<span class="cc-modifier neutral">Inga modifikationer</span>'
                    }
                </div>
            </div>
            
            <div class="cc-detail-section">
                <h4>Förflyttning</h4>
                <p>${kin.baseMovement} meter per runda</p>
            </div>
            
            <div class="cc-detail-section">
                <h4>Språk</h4>
                <p>${kin.languages.join(', ')}</p>
            </div>
        </div>
    `;
}

// === STEP 3: PROFESSION (YRKE) ===
function renderProfessionStep() {
    return `
        <div class="cc-step-content cc-profession-step animate-in">
            <h2 class="cc-title">Välj ditt yrke</h2>
            <p class="cc-description">Ditt yrke definierar dina färdigheter och din roll i gruppen.</p>
            
            <div class="cc-search-box">
                <input type="text" 
                       class="cc-search-input" 
                       placeholder="Sök yrke..."
                       oninput="filterProfessions(this.value)">
            </div>
            
            <div class="cc-profession-list" id="ccProfessionList">
                ${Object.entries(DOD_DATA.professions).map(([key, prof]) => `
                    <div class="cc-profession-item ${currentCharacter.profession === key ? 'selected' : ''}" 
                         onclick="selectProfession('${key}')"
                         data-name="${prof.name.toLowerCase()}">
                        <div class="cc-profession-icon">${getProfessionIcon(key)}</div>
                        <div class="cc-profession-info">
                            <h3 class="cc-profession-name">${prof.name}</h3>
                            <p class="cc-profession-desc">${prof.description}</p>
                        </div>
                        <div class="cc-profession-key">
                            <span class="cc-key-attr">${prof.keyAttribute}</span>
                        </div>
                        <div class="cc-profession-arrow">❯</div>
                    </div>
                `).join('')}
            </div>
            
            ${currentCharacter.profession ? renderProfessionDetails(currentCharacter.profession) : ''}
        </div>
    `;
}

function getProfessionIcon(profession) {
    const icons = {
        bard: '🎵',
        hantverkare: '🔨',
        jagare: '🏹',
        krigare: '⚔️',
        lard: '📚',
        magiker: '✨',
        nasare: '💰',
        riddare: '🛡️',
        sjofarare: '⚓',
        tjuv: '🗡️'
    };
    return icons[profession] || '⚔️';
}

function filterProfessions(query) {
    const items = document.querySelectorAll('.cc-profession-item');
    items.forEach(item => {
        const name = item.dataset.name;
        item.style.display = name.includes(query.toLowerCase()) ? '' : 'none';
    });
}

function selectProfession(profKey) {
    currentCharacter.profession = profKey;
    
    const content = document.getElementById('ccContent');
    content.innerHTML = renderProfessionStep();
    
    updatePreview();
    updateNavigation();
}

function renderProfessionDetails(profKey) {
    const prof = DOD_DATA.professions[profKey];
    
    return `
        <div class="cc-details-panel animate-in">
            <h3>${prof.name}</h3>
            
            <div class="cc-detail-section">
                <h4>Hjälteförmåga: ${prof.heroicAbility.name}</h4>
                <p>${prof.heroicAbility.description}</p>
                <span class="cc-cost-badge">${prof.heroicAbility.cost}</span>
            </div>
            
            ${prof.isMage ? `
                <div class="cc-detail-section cc-magic-schools">
                    <h4>Välj magiskola</h4>
                    <div class="cc-magic-school-buttons">
                        ${prof.magicSchools.map(school => `
                            <button class="cc-magic-school-btn ${currentCharacter.magicSchool === school ? 'selected' : ''}"
                                    onclick="selectMagicSchool('${school}')">
                                ${getMagicSchoolIcon(school)} ${school}
                            </button>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
            
            <div class="cc-detail-section">
                <h4>Yrkesfärdigheter</h4>
                <div class="cc-skills-list">
                    ${prof.skills.map(skill => `
                        <span class="cc-skill-tag">${skill}</span>
                    `).join('')}
                </div>
            </div>
            
            <div class="cc-detail-section">
                <h4>Viktigaste grundegenskap</h4>
                <span class="cc-key-attribute">${DOD_DATA.attributeNames[prof.keyAttribute]} (${prof.keyAttribute})</span>
            </div>
        </div>
    `;
}

function getMagicSchoolIcon(school) {
    const icons = {
        'Elementalism': '🔥',
        'Mentalism': '🧠',
        'Animism': '🌿'
    };
    return icons[school] || '✨';
}

function selectMagicSchool(school) {
    currentCharacter.magicSchool = school;
    
    const content = document.getElementById('ccContent');
    content.innerHTML = renderProfessionStep();
    
    updatePreview();
}

// === STEP 4: AGE ===
function renderAgeStep() {
    return `
        <div class="cc-step-content cc-age-step animate-in">
            <h2 class="cc-title">Hur gammal är ${currentCharacter.name || 'din hjälte'}?</h2>
            <p class="cc-description">Din ålder påverkar dina grundegenskaper och hur många färdigheter du börjar med.</p>
            
            <div class="cc-age-cards">
                ${Object.entries(DOD_DATA.ages).map(([key, age]) => `
                    <div class="cc-age-card ${currentCharacter.age === key ? 'selected' : ''}" 
                         onclick="selectAge('${key}')">
                        <div class="cc-age-icon">${getAgeIcon(key)}</div>
                        <h3 class="cc-age-name">${age.name}</h3>
                        <p class="cc-age-description">${age.description}</p>
                        
                        <div class="cc-age-stats">
                            <div class="cc-age-modifiers">
                                ${Object.entries(age.modifiers).map(([attr, mod]) => `
                                    <span class="cc-age-mod ${mod > 0 ? 'positive' : mod < 0 ? 'negative' : 'neutral'}">
                                        ${attr}: ${mod > 0 ? '+' : ''}${mod}
                                    </span>
                                `).join('')}
                            </div>
                            <div class="cc-age-skills">
                                <span class="cc-skill-count">${age.trainedSkills}</span>
                                <span class="cc-skill-label">tränade färdigheter</span>
                            </div>
                        </div>
                        
                        <div class="cc-card-check">✓</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function getAgeIcon(age) {
    const icons = {
        ung: '🌱',
        medelalders: '⚔️',
        gammal: '📜'
    };
    return icons[age] || '⏳';
}

function selectAge(ageKey) {
    currentCharacter.age = ageKey;
    recalculateAttributes();
    
    const content = document.getElementById('ccContent');
    content.innerHTML = renderAgeStep();
    
    updatePreview();
    updateNavigation();
}

// === STEP 5: ATTRIBUTES ===
function renderAttributesStep() {
    return `
        <div class="cc-step-content cc-attributes-step animate-in">
            <h2 class="cc-title">Slå dina grundegenskaper</h2>
            <p class="cc-description">Slå 4T6 och ta bort den lägsta tärningen. Du kan placera värdena var du vill.</p>
            
            <div class="cc-roll-section">
                <button class="cc-roll-all-btn" onclick="rollAllAttributes()">
                    🎲 Slå alla egenskaper
                </button>
                <button class="cc-roll-reset-btn" onclick="resetAttributes()">
                    ↺ Börja om
                </button>
            </div>
            
            <div class="cc-dice-pool" id="ccDicePool">
                ${renderDicePool()}
            </div>
            
            <div class="cc-attributes-grid">
                ${DOD_DATA.attributes.map(attr => `
                    <div class="cc-attribute-slot" data-attr="${attr}">
                        <div class="cc-attr-header">
                            <span class="cc-attr-name">${DOD_DATA.attributeNames[attr]}</span>
                            <span class="cc-attr-abbr">${attr}</span>
                        </div>
                        <div class="cc-attr-value-box ${getAttributeDropZoneClass(attr)}" 
                             ondrop="dropAttribute(event, '${attr}')"
                             ondragover="allowDrop(event)">
                            <span class="cc-attr-value" id="attr-${attr}">${currentCharacter.attributes[attr]}</span>
                        </div>
                        <div class="cc-attr-modifiers">
                            ${renderAttributeModifiers(attr)}
                        </div>
                        <p class="cc-attr-desc">${DOD_DATA.attributeDescriptions[attr]}</p>
                    </div>
                `).join('')}
            </div>
            
            <div class="cc-derived-stats">
                <h3>Härledda värden</h3>
                <div class="cc-derived-grid">
                    <div class="cc-derived-stat">
                        <span class="cc-derived-label">Kroppspoäng (KP)</span>
                        <span class="cc-derived-value" id="derived-kp">${currentCharacter.attributes.FYS}</span>
                    </div>
                    <div class="cc-derived-stat">
                        <span class="cc-derived-label">Viljepoäng (VP)</span>
                        <span class="cc-derived-value" id="derived-vp">${currentCharacter.attributes.PSY}</span>
                    </div>
                    <div class="cc-derived-stat">
                        <span class="cc-derived-label">Förflyttning</span>
                        <span class="cc-derived-value" id="derived-move">${calculateMovement()}</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderDicePool() {
    if (currentCharacter.rolledAttributes.length === 0) {
        return '<p class="cc-dice-pool-empty">Klicka på "Slå alla egenskaper" för att börja</p>';
    }
    
    const unassigned = currentCharacter.rolledAttributes.filter(r => !r.assigned);
    
    if (unassigned.length === 0) {
        return '<p class="cc-dice-pool-complete">✓ Alla värden placerade!</p>';
    }
    
    return unassigned.map((roll, index) => `
        <div class="cc-dice-result" 
             draggable="true"
             ondragstart="dragAttribute(event, ${roll.originalIndex})"
             onclick="selectDieForPlacement(${roll.originalIndex})">
            <div class="cc-dice-value">${roll.total}</div>
            <div class="cc-dice-breakdown">${roll.dice.join(' + ')} (−${roll.dropped})</div>
        </div>
    `).join('');
}

function rollAllAttributes() {
    currentCharacter.rolledAttributes = [];
    
    // Roll 5 sets of 4d6 drop lowest
    for (let i = 0; i < 5; i++) {
        const roll = roll4d6DropLowest();
        roll.originalIndex = i;
        roll.assigned = false;
        currentCharacter.rolledAttributes.push(roll);
    }
    
    // Animate the rolls
    animateDiceRolls();
}

function roll4d6DropLowest() {
    let dice = [];
    for (let i = 0; i < 4; i++) {
        dice.push(Math.floor(Math.random() * 6) + 1);
    }
    
    // Sort to find lowest
    const sorted = [...dice].sort((a, b) => a - b);
    const dropped = sorted[0];
    const kept = sorted.slice(1);
    const total = kept.reduce((sum, d) => sum + d, 0);
    
    return { dice: kept, dropped, total };
}

function animateDiceRolls() {
    const pool = document.getElementById('ccDicePool');
    pool.innerHTML = '<div class="cc-rolling">🎲 Slår tärningar...</div>';
    
    // Simulate rolling animation
    let count = 0;
    const interval = setInterval(() => {
        count++;
        const randomVals = currentCharacter.rolledAttributes.map(() => 
            Math.floor(Math.random() * 16) + 3
        );
        
        pool.innerHTML = randomVals.map(v => `
            <div class="cc-dice-result rolling">
                <div class="cc-dice-value">${v}</div>
            </div>
        `).join('');
        
        if (count >= 10) {
            clearInterval(interval);
            pool.innerHTML = renderDicePool();
        }
    }, 50);
}

function resetAttributes() {
    currentCharacter.rolledAttributes = [];
    currentCharacter.baseAttributes = { STY: 10, FYS: 10, SMI: 10, INT: 10, PSY: 10 };
    recalculateAttributes();
    
    const content = document.getElementById('ccContent');
    content.innerHTML = renderAttributesStep();
}

let selectedDieIndex = null;

function selectDieForPlacement(index) {
    selectedDieIndex = index;
    
    // Highlight available slots
    document.querySelectorAll('.cc-attr-value-box').forEach(box => {
        const attr = box.closest('.cc-attribute-slot').dataset.attr;
        const hasValue = currentCharacter.rolledAttributes.find(r => r.assignedTo === attr);
        if (!hasValue) {
            box.classList.add('awaiting-drop');
        }
    });
    
    // Show instruction
    const pool = document.getElementById('ccDicePool');
    const instruction = document.createElement('p');
    instruction.className = 'cc-placement-instruction';
    instruction.textContent = 'Klicka på en grundegenskap för att placera värdet';
    pool.appendChild(instruction);
}

function getAttributeDropZoneClass(attr) {
    const hasValue = currentCharacter.rolledAttributes.find(r => r.assignedTo === attr);
    return hasValue ? 'has-value' : '';
}

function allowDrop(event) {
    event.preventDefault();
}

function dragAttribute(event, index) {
    event.dataTransfer.setData('text/plain', index);
}

function dropAttribute(event, attr) {
    event.preventDefault();
    const index = parseInt(event.dataTransfer.getData('text/plain'));
    assignAttributeValue(index, attr);
}

function assignAttributeValue(rollIndex, attr) {
    const roll = currentCharacter.rolledAttributes[rollIndex];
    if (!roll || roll.assigned) return;
    
    // Check if attribute already has a value
    const existingRoll = currentCharacter.rolledAttributes.find(r => r.assignedTo === attr);
    if (existingRoll) {
        existingRoll.assigned = false;
        existingRoll.assignedTo = null;
    }
    
    // Assign new value
    roll.assigned = true;
    roll.assignedTo = attr;
    currentCharacter.baseAttributes[attr] = roll.total;
    
    // Recalculate with modifiers
    recalculateAttributes();
    
    // Re-render
    const content = document.getElementById('ccContent');
    content.innerHTML = renderAttributesStep();
    
    updateNavigation();
}

function renderAttributeModifiers(attr) {
    let mods = [];
    
    // Kin modifiers
    if (currentCharacter.kin) {
        const kinMod = DOD_DATA.kin[currentCharacter.kin].modifiers[attr];
        if (kinMod) {
            mods.push({ source: DOD_DATA.kin[currentCharacter.kin].name, value: kinMod });
        }
    }
    
    // Age modifiers
    if (currentCharacter.age) {
        const ageMod = DOD_DATA.ages[currentCharacter.age].modifiers[attr];
        if (ageMod) {
            mods.push({ source: DOD_DATA.ages[currentCharacter.age].name, value: ageMod });
        }
    }
    
    if (mods.length === 0) return '';
    
    return mods.map(m => `
        <span class="cc-mod-tag ${m.value > 0 ? 'positive' : 'negative'}">
            ${m.source}: ${m.value > 0 ? '+' : ''}${m.value}
        </span>
    `).join('');
}

function recalculateAttributes() {
    // Start with base values
    const attrs = { ...currentCharacter.baseAttributes };
    
    // Apply kin modifiers
    if (currentCharacter.kin) {
        const kinMods = DOD_DATA.kin[currentCharacter.kin].modifiers;
        for (const [attr, mod] of Object.entries(kinMods)) {
            if (attrs[attr] !== undefined) {
                attrs[attr] += mod;
            }
        }
    }
    
    // Apply age modifiers
    if (currentCharacter.age) {
        const ageMods = DOD_DATA.ages[currentCharacter.age].modifiers;
        for (const [attr, mod] of Object.entries(ageMods)) {
            if (attrs[attr] !== undefined) {
                attrs[attr] += mod;
            }
        }
    }
    
    // Clamp values to 3-18
    for (const attr of DOD_DATA.attributes) {
        attrs[attr] = Math.max(3, Math.min(18, attrs[attr]));
    }
    
    currentCharacter.attributes = attrs;
}

function calculateMovement() {
    if (!currentCharacter.kin) return 10;
    
    const baseMove = DOD_DATA.kin[currentCharacter.kin].baseMovement;
    const smiMod = Math.floor((currentCharacter.attributes.SMI - 10) / 2);
    
    return baseMove + smiMod;
}

// === STEP 6: EQUIPMENT ===
function renderEquipmentStep() {
    const prof = currentCharacter.profession ? DOD_DATA.professions[currentCharacter.profession] : null;
    
    if (!prof) {
        return `<div class="cc-step-content"><p>Välj ett yrke först.</p></div>`;
    }
    
    return `
        <div class="cc-step-content cc-equipment-step animate-in">
            <h2 class="cc-title">Utrustning</h2>
            <p class="cc-description">Som ${prof.name.toLowerCase()} börjar du med ett av följande utrustningspaket.</p>
            
            <div class="cc-equipment-roll">
                <button class="cc-roll-equipment-btn ${currentCharacter.equipmentRoll !== null ? 'rolled' : ''}" 
                        onclick="rollEquipment()">
                    🎲 ${currentCharacter.equipmentRoll !== null ? `Du slog ${currentCharacter.equipmentRoll}` : 'Slå för utrustning (1T6)'}
                </button>
            </div>
            
            <div class="cc-equipment-options">
                ${prof.equipment.map((eq, index) => `
                    <div class="cc-equipment-option ${isEquipmentSelected(eq.roll) ? 'selected' : ''}">
                        <div class="cc-equipment-roll-range">${eq.roll}</div>
                        <div class="cc-equipment-items">
                            ${eq.items.map(item => `
                                <span class="cc-equipment-item">${item}</span>
                            `).join('')}
                        </div>
                    </div>
                `).join('')}
            </div>
            
            ${currentCharacter.equipmentRoll !== null ? `
                <div class="cc-equipment-selected">
                    <h3>Din utrustning</h3>
                    <div class="cc-equipment-list">
                        ${currentCharacter.equipment.map(item => `
                            <div class="cc-equipment-item-card">
                                <span class="cc-item-icon">${getItemIcon(item)}</span>
                                <span class="cc-item-name">${item}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

function rollEquipment() {
    const roll = Math.floor(Math.random() * 6) + 1;
    currentCharacter.equipmentRoll = roll;
    
    // Find matching equipment
    const prof = DOD_DATA.professions[currentCharacter.profession];
    const equipment = prof.equipment.find(eq => {
        const [min, max] = eq.roll.split('-').map(Number);
        return roll >= min && roll <= max;
    });
    
    currentCharacter.equipment = equipment ? equipment.items : [];
    
    // Animate
    const btn = document.querySelector('.cc-roll-equipment-btn');
    btn.classList.add('rolling');
    
    setTimeout(() => {
        const content = document.getElementById('ccContent');
        content.innerHTML = renderEquipmentStep();
    }, 500);
    
    updateNavigation();
}

function isEquipmentSelected(rollRange) {
    if (currentCharacter.equipmentRoll === null) return false;
    
    const [min, max] = rollRange.split('-').map(Number);
    return currentCharacter.equipmentRoll >= min && currentCharacter.equipmentRoll <= max;
}

function getItemIcon(item) {
    const itemLower = item.toLowerCase();
    
    if (itemLower.includes('svärd') || itemLower.includes('sabel')) return '⚔️';
    if (itemLower.includes('yxa')) return '🪓';
    if (itemLower.includes('båge') || itemLower.includes('armborst')) return '🏹';
    if (itemLower.includes('stav')) return '🪄';
    if (itemLower.includes('kniv')) return '🗡️';
    if (itemLower.includes('sköld')) return '🛡️';
    if (itemLower.includes('rustning') || itemLower.includes('brynja')) return '🛡️';
    if (itemLower.includes('ryggsäck')) return '🎒';
    if (itemLower.includes('mat') || itemLower.includes('ration')) return '🍖';
    if (itemLower.includes('rep')) return '🪢';
    if (itemLower.includes('fackla') || itemLower.includes('ljus')) return '🔥';
    if (itemLower.includes('bok')) return '📕';
    if (itemLower.includes('mynt') || itemLower.includes('silver')) return '💰';
    if (itemLower.includes('fokus')) return '🔮';
    
    return '📦';
}

// === STEP 7: SUMMARY ===
function renderSummaryStep() {
    const kin = currentCharacter.kin ? DOD_DATA.kin[currentCharacter.kin] : null;
    const prof = currentCharacter.profession ? DOD_DATA.professions[currentCharacter.profession] : null;
    const age = currentCharacter.age ? DOD_DATA.ages[currentCharacter.age] : null;
    
    return `
        <div class="cc-step-content cc-summary-step animate-in">
            <h2 class="cc-title">Din karaktär är redo!</h2>
            
            <div class="cc-character-sheet">
                <div class="cc-sheet-header">
                    <div class="cc-sheet-portrait">
                        ${getKinIcon(currentCharacter.kin)}
                    </div>
                    <div class="cc-sheet-identity">
                        <h2 class="cc-sheet-name">${currentCharacter.name || 'Namnlös'}</h2>
                        <p class="cc-sheet-subtitle">
                            ${age ? age.name : ''} ${kin ? kin.name : ''} ${prof ? prof.name : ''}
                        </p>
                    </div>
                </div>
                
                <div class="cc-sheet-body">
                    <div class="cc-sheet-section cc-sheet-attributes">
                        <h3>Grundegenskaper</h3>
                        <div class="cc-sheet-attr-grid">
                            ${DOD_DATA.attributes.map(attr => `
                                <div class="cc-sheet-attr">
                                    <span class="cc-sheet-attr-name">${attr}</span>
                                    <span class="cc-sheet-attr-value">${currentCharacter.attributes[attr]}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="cc-sheet-section cc-sheet-derived">
                        <h3>Härledda värden</h3>
                        <div class="cc-sheet-derived-grid">
                            <div class="cc-sheet-derived-item">
                                <span class="cc-derived-name">KP</span>
                                <span class="cc-derived-val">${currentCharacter.attributes.FYS}</span>
                            </div>
                            <div class="cc-sheet-derived-item">
                                <span class="cc-derived-name">VP</span>
                                <span class="cc-derived-val">${currentCharacter.attributes.PSY}</span>
                            </div>
                            <div class="cc-sheet-derived-item">
                                <span class="cc-derived-name">Förflyttning</span>
                                <span class="cc-derived-val">${calculateMovement()}m</span>
                            </div>
                        </div>
                    </div>
                    
                    ${kin ? `
                        <div class="cc-sheet-section">
                            <h3>Släktesförmåga</h3>
                            <div class="cc-sheet-ability">
                                <strong>${kin.ability.name}</strong>
                                <p>${kin.ability.description}</p>
                            </div>
                            ${kin.secondAbility ? `
                                <div class="cc-sheet-ability">
                                    <strong>${kin.secondAbility.name}</strong>
                                    <p>${kin.secondAbility.description}</p>
                                </div>
                            ` : ''}
                        </div>
                    ` : ''}
                    
                    ${prof ? `
                        <div class="cc-sheet-section">
                            <h3>Hjälteförmåga</h3>
                            <div class="cc-sheet-ability">
                                <strong>${prof.heroicAbility.name}</strong>
                                <p>${prof.heroicAbility.description}</p>
                            </div>
                            ${currentCharacter.magicSchool ? `
                                <div class="cc-sheet-ability">
                                    <strong>Magiskola: ${currentCharacter.magicSchool}</strong>
                                </div>
                            ` : ''}
                        </div>
                        
                        <div class="cc-sheet-section">
                            <h3>Yrkesfärdigheter</h3>
                            <div class="cc-sheet-skills">
                                ${prof.skills.map(skill => `
                                    <span class="cc-sheet-skill">${skill}</span>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                    
                    ${currentCharacter.equipment.length > 0 ? `
                        <div class="cc-sheet-section">
                            <h3>Utrustning</h3>
                            <div class="cc-sheet-equipment">
                                ${currentCharacter.equipment.map(item => `
                                    <span class="cc-sheet-item">${getItemIcon(item)} ${item}</span>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
            
            <div class="cc-final-actions">
                <button class="btn btn-gold btn-large cc-create-btn" onclick="finalizeCharacter()">
                    ✨ Skapa karaktär
                </button>
            </div>
        </div>
    `;
}

// === NAVIGATION ===

function canProceed() {
    switch(currentCharacter.step) {
        case 1: return currentCharacter.name.trim().length > 0;
        case 2: return currentCharacter.kin !== null;
        case 3: 
            if (currentCharacter.profession === null) return false;
            if (DOD_DATA.professions[currentCharacter.profession].isMage && !currentCharacter.magicSchool) return false;
            return true;
        case 4: return currentCharacter.age !== null;
        case 5: 
            const allAssigned = currentCharacter.rolledAttributes.length === 5 && 
                               currentCharacter.rolledAttributes.every(r => r.assigned);
            return allAssigned;
        case 6: return currentCharacter.equipmentRoll !== null;
        case 7: return true;
        default: return false;
    }
}

function nextStep() {
    if (!canProceed()) return;
    
    if (currentCharacter.step < 7) {
        currentCharacter.step++;
        renderWizard(document.getElementById('characterCreator'));
    }
}

function prevStep() {
    if (currentCharacter.step > 1) {
        currentCharacter.step--;
        renderWizard(document.getElementById('characterCreator'));
    }
}

function goToStep(step) {
    // Only allow going to completed steps or current step
    if (step <= currentCharacter.step) {
        currentCharacter.step = step;
        renderWizard(document.getElementById('characterCreator'));
    }
}

function updateNavigation() {
    const nextBtn = document.querySelector('.cc-nav-next');
    const prevBtn = document.querySelector('.cc-nav-prev');
    
    if (nextBtn) {
        nextBtn.disabled = !canProceed();
        nextBtn.classList.toggle('disabled', !canProceed());
    }
    
    if (prevBtn) {
        prevBtn.disabled = currentCharacter.step === 1;
        prevBtn.classList.toggle('disabled', currentCharacter.step === 1);
    }
    
    // Update step indicators
    document.querySelectorAll('.cc-step').forEach(stepEl => {
        const stepNum = parseInt(stepEl.dataset.step);
        stepEl.classList.toggle('active', stepNum === currentCharacter.step);
        stepEl.classList.toggle('completed', stepNum < currentCharacter.step);
    });
}

function updatePreview() {
    const subtitle = document.getElementById('ccSubtitle');
    if (!subtitle) return;
    
    const parts = [];
    
    if (currentCharacter.age) {
        parts.push(DOD_DATA.ages[currentCharacter.age].name);
    }
    
    if (currentCharacter.kin) {
        parts.push(DOD_DATA.kin[currentCharacter.kin].name);
    }
    
    if (currentCharacter.profession) {
        parts.push(DOD_DATA.professions[currentCharacter.profession].name);
    }
    
    subtitle.textContent = parts.length > 0 ? parts.join(' ') : 'Välj ditt öde';
    
    // Update portrait
    const portrait = document.getElementById('ccPortrait');
    if (portrait && currentCharacter.kin) {
        portrait.innerHTML = `<span class="cc-portrait-icon">${getKinIcon(currentCharacter.kin)}</span>`;
    }
}

// === FINALIZE ===

async function finalizeCharacter() {
    const kin = DOD_DATA.kin[currentCharacter.kin];
    const prof = DOD_DATA.professions[currentCharacter.profession];
    const age = DOD_DATA.ages[currentCharacter.age];
    
    const characterData = {
        name: currentCharacter.name,
        kin: kin.name,
        kinKey: currentCharacter.kin,
        profession: prof.name,
        professionKey: currentCharacter.profession,
        age: age.name,
        ageKey: currentCharacter.age,
        level: 1,
        attributes: currentCharacter.attributes,
        hp: currentCharacter.attributes.FYS,
        maxHp: currentCharacter.attributes.FYS,
        vp: currentCharacter.attributes.PSY,
        maxVp: currentCharacter.attributes.PSY,
        movement: calculateMovement(),
        kinAbility: kin.ability,
        kinSecondAbility: kin.secondAbility || null,
        heroicAbility: prof.heroicAbility,
        magicSchool: currentCharacter.magicSchool,
        skills: prof.skills,
        trainedSkillCount: age.trainedSkills,
        equipment: currentCharacter.equipment,
        languages: kin.languages,
        // Legacy compatibility
        race: kin.name,
        class: prof.name
    };
    
    try {
        // Save to Firebase
        const character = await CharacterService.createCharacter(characterData);
        
        // Close modal
        document.getElementById('characterCreatorModal').classList.remove('active');
        
        // Refresh character list
        await loadCharacters();
        
        // Show success
        showNotification(`${characterData.name} har skapats!`, 'success');
        
    } catch (error) {
        console.error('Error creating character:', error);
        showNotification(error.message, 'error');
    }
}

// === UTILITY ===

function showNotification(message, type) {
    // Create toast notification
    const toast = document.createElement('div');
    toast.className = `cc-toast cc-toast-${type}`;
    toast.innerHTML = `
        <span class="cc-toast-icon">${type === 'success' ? '✓' : '✗'}</span>
        <span class="cc-toast-message">${message}</span>
    `;
    
    document.body.appendChild(toast);
    
    // Animate in
    setTimeout(() => toast.classList.add('show'), 10);
    
    // Remove after delay
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
