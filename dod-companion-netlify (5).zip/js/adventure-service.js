// Adventure Service - Hantera äventyr i Firebase

const AdventureService = {
    // Skapa nytt äventyr
    async createAdventure(adventureData) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        const adventure = {
            ...adventureData,
            authorId: user.uid,
            authorName: user.displayName || user.email,
            isPublic: adventureData.isPublic || false,
            sharedWith: adventureData.sharedWith || [],
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        };
        
        const docRef = await db.collection('adventures').add(adventure);
        return { id: docRef.id, ...adventure };
    },
    
    // Hämta alla äventyr för inloggad användare
    async getUserAdventures() {
        const user = getCurrentUser();
        if (!user) return [];
        
        const snapshot = await db.collection('adventures')
            .where('authorId', '==', user.uid)
            .orderBy('updatedAt', 'desc')
            .get();
        
        return snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
    },
    
    // Hämta äventyr delade med användaren
    async getSharedAdventures() {
        const user = getCurrentUser();
        if (!user) return [];
        
        const snapshot = await db.collection('adventures')
            .where('sharedWith', 'array-contains', user.uid)
            .orderBy('updatedAt', 'desc')
            .get();
        
        return snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
    },
    
    // Hämta publika äventyr
    async getPublicAdventures(limit = 20) {
        const snapshot = await db.collection('adventures')
            .where('isPublic', '==', true)
            .orderBy('createdAt', 'desc')
            .limit(limit)
            .get();
        
        return snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
    },
    
    // Hämta ett specifikt äventyr
    async getAdventure(adventureId) {
        const doc = await db.collection('adventures').doc(adventureId).get();
        if (!doc.exists) throw new Error('Äventyr inte hittat');
        
        const adventure = { id: doc.id, ...doc.data() };
        
        // Kontrollera åtkomst
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        if (adventure.authorId !== user.uid && 
            !adventure.isPublic && 
            !adventure.sharedWith.includes(user.uid)) {
            throw new Error('Du har inte åtkomst till detta äventyr');
        }
        
        return adventure;
    },
    
    // Uppdatera äventyr
    async updateAdventure(adventureId, updates) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Verifiera att användaren äger äventyret
        const adventure = await this.getAdventure(adventureId);
        if (adventure.authorId !== user.uid) {
            throw new Error('Du har inte behörighet att uppdatera detta äventyr');
        }
        
        await db.collection('adventures').doc(adventureId).update({
            ...updates,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        return await this.getAdventure(adventureId);
    },
    
    // Ta bort äventyr
    async deleteAdventure(adventureId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Verifiera att användaren äger äventyret
        const adventure = await this.getAdventure(adventureId);
        if (adventure.authorId !== user.uid) {
            throw new Error('Du har inte behörighet att ta bort detta äventyr');
        }
        
        await db.collection('adventures').doc(adventureId).delete();
    },
    
    // Dela äventyr med specifik användare (via email)
    async shareAdventure(adventureId, userEmail) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Hämta äventyret
        const adventure = await this.getAdventure(adventureId);
        if (adventure.authorId !== user.uid) {
            throw new Error('Du har inte behörighet att dela detta äventyr');
        }
        
        // Hitta användare med denna email
        const userSnapshot = await db.collection('users')
            .where('email', '==', userEmail)
            .get();
        
        if (userSnapshot.empty) {
            throw new Error('Användare inte hittad');
        }
        
        const targetUserId = userSnapshot.docs[0].id;
        
        // Lägg till i sharedWith array
        await db.collection('adventures').doc(adventureId).update({
            sharedWith: firebase.firestore.FieldValue.arrayUnion(targetUserId),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    },
    
    // Ta bort delning
    async unshareAdventure(adventureId, userId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        const adventure = await this.getAdventure(adventureId);
        if (adventure.authorId !== user.uid) {
            throw new Error('Du har inte behörighet');
        }
        
        await db.collection('adventures').doc(adventureId).update({
            sharedWith: firebase.firestore.FieldValue.arrayRemove(userId),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    },
    
    // Gör äventyr publikt/privat
    async togglePublic(adventureId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        const adventure = await this.getAdventure(adventureId);
        if (adventure.authorId !== user.uid) {
            throw new Error('Du har inte behörighet');
        }
        
        await db.collection('adventures').doc(adventureId).update({
            isPublic: !adventure.isPublic,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    }
};
