// Character Service - Hantera karaktärer i Firebase

const CharacterService = {
    // Skapa ny karaktär
    async createCharacter(characterData) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        const character = {
            ...characterData,
            ownerId: user.uid,
            ownerName: user.displayName || user.email,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        };
        
        const docRef = await db.collection('characters').add(character);
        return { id: docRef.id, ...character };
    },
    
    // Hämta alla karaktärer för inloggad användare
    async getUserCharacters() {
        const user = getCurrentUser();
        if (!user) {
            console.log('[CharacterService] No user logged in');
            return [];
        }
        
        console.log('[CharacterService] Fetching characters for user:', user.uid);
        
        try {
            // Simple query without orderBy to avoid index requirement
            const snapshot = await db.collection('characters')
                .where('ownerId', '==', user.uid)
                .get();
            
            console.log('[CharacterService] Query completed. Documents:', snapshot.size);
            
            const characters = snapshot.docs.map(doc => {
                const data = doc.data();
                console.log('[CharacterService] Character found:', doc.id, data.name);
                return {
                    id: doc.id,
                    ...data
                };
            });
            
            // Sort client-side instead
            characters.sort((a, b) => {
                const aTime = a.createdAt?.toMillis?.() || 0;
                const bTime = b.createdAt?.toMillis?.() || 0;
                return bTime - aTime; // Descending
            });
            
            console.log('[CharacterService] Total characters:', characters.length);
            return characters;
        } catch (error) {
            console.error('[CharacterService] Error fetching characters:', error);
            throw error;
        }
    },
    
    // Hämta en specifik karaktär
    async getCharacter(characterId) {
        const doc = await db.collection('characters').doc(characterId).get();
        if (!doc.exists) throw new Error('Karaktär inte hittad');
        
        return { id: doc.id, ...doc.data() };
    },
    
    // Uppdatera karaktär
    async updateCharacter(characterId, updates) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Verifiera att användaren äger karaktären
        const character = await this.getCharacter(characterId);
        if (character.ownerId !== user.uid) {
            throw new Error('Du har inte behörighet att uppdatera denna karaktär');
        }
        
        await db.collection('characters').doc(characterId).update({
            ...updates,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        return await this.getCharacter(characterId);
    },
    
    // Ta bort karaktär
    async deleteCharacter(characterId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        // Verifiera att användaren äger karaktären
        const character = await this.getCharacter(characterId);
        if (character.ownerId !== user.uid) {
            throw new Error('Du har inte behörighet att ta bort denna karaktär');
        }
        
        await db.collection('characters').doc(characterId).delete();
    },
    
    // Dela karaktär med kampanj
    async shareWithCampaign(characterId, campaignId) {
        const user = getCurrentUser();
        if (!user) throw new Error('Användare inte inloggad');
        
        await db.collection('characters').doc(characterId).update({
            campaignId: campaignId,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    },
    
    // Hämta karaktärer i en kampanj
    async getCampaignCharacters(campaignId) {
        const snapshot = await db.collection('characters')
            .where('campaignId', '==', campaignId)
            .get();
        
        return snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
    },
    
    // Real-time listener för användarens karaktärer
    onCharactersChange(callback) {
        const user = getCurrentUser();
        if (!user) return () => {};
        
        return db.collection('characters')
            .where('ownerId', '==', user.uid)
            .onSnapshot(snapshot => {
                const characters = snapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                }));
                callback(characters);
            });
    }
};

// Hjälpfunktion för att räkna ut modifierare från attribut
function calculateModifier(attribute) {
    return Math.floor((attribute - 10) / 2);
}

// Hjälpfunktion för att validera karaktärsdata
function validateCharacter(character) {
    const required = ['name'];
    for (const field of required) {
        if (!character[field]) {
            throw new Error(`Fält ${field} är obligatoriskt`);
        }
    }
    
    return true;
}
