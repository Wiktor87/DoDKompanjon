// Super Debug System - Visible on screen

const SuperDebug = {
    logs: [],
    
    init() {
        console.log('[SuperDebug] Initializing...');
        this.checkFirebaseInit();
    },
    
    checkFirebaseInit() {
        const status = document.createElement('div');
        status.className = 'firebase-status';
        status.innerHTML = '<h4>Firebase Status</h4><div id="firebaseStatusItems"></div>';
        document.body.appendChild(status);
        
        const items = document.getElementById('firebaseStatusItems');
        
        // Check if Firebase is loaded
        if (typeof firebase === 'undefined') {
            items.innerHTML += '<div class="status-item fail">Firebase SDK not loaded</div>';
            status.classList.add('error');
            this.showBigError('Firebase SDK saknas!', 'Firebase JavaScript-biblioteket laddades inte. Kontrollera internet-anslutningen.');
            return;
        }
        items.innerHTML += '<div class="status-item ok">Firebase SDK loaded</div>';
        
        // Check if firebase config exists
        if (typeof firebaseConfig === 'undefined') {
            items.innerHTML += '<div class="status-item fail">Firebase config missing</div>';
            status.classList.add('error');
            return;
        }
        items.innerHTML += '<div class="status-item ok">Config found</div>';
        
        // Check if auth is available
        if (typeof auth === 'undefined') {
            items.innerHTML += '<div class="status-item fail">Auth not initialized</div>';
            status.classList.add('error');
            return;
        }
        items.innerHTML += '<div class="status-item ok">Auth initialized</div>';
        
        // Check if firestore is available
        if (typeof db === 'undefined') {
            items.innerHTML += '<div class="status-item fail">Firestore not initialized</div>';
            status.classList.add('error');
            return;
        }
        items.innerHTML += '<div class="status-item ok">Firestore initialized</div>';
        
        status.classList.add('success');
        
        // Auto-hide after 3 seconds if all OK
        setTimeout(() => {
            status.style.opacity = '0';
            setTimeout(() => status.remove(), 300);
        }, 3000);
    },
    
    showBigError(title, message, details = null) {
        const alert = document.createElement('div');
        alert.className = 'debug-alert active';
        alert.innerHTML = `
            <h3>${title}</h3>
            <p>${message}</p>
            ${details ? `<div class="error-details">${details}</div>` : ''}
            <button class="btn btn-gold close-debug" onclick="this.parentElement.remove()">
                Stäng
            </button>
        `;
        document.body.appendChild(alert);
        
        console.error('[SuperDebug]', title, message, details);
    },
    
    logAuthAttempt(method, email = null) {
        console.log(`[SuperDebug] Auth attempt: ${method}`, email);
        
        const status = document.querySelector('.firebase-status');
        if (status) {
            const item = document.createElement('div');
            item.className = 'status-item';
            item.textContent = `Försöker logga in med ${method}...`;
            status.querySelector('#firebaseStatusItems').appendChild(item);
        }
    },
    
    logAuthSuccess(user) {
        console.log('[SuperDebug] Auth success:', user.email);
        
        const alert = document.createElement('div');
        alert.className = 'debug-alert active';
        alert.style.borderColor = 'var(--accent-green)';
        alert.innerHTML = `
            <h3 style="color: var(--accent-green);">✅ Inloggning lyckades!</h3>
            <p>Du är nu inloggad som: <strong>${user.email}</strong></p>
            <button class="btn btn-gold close-debug" onclick="this.parentElement.remove()">
                Fortsätt
            </button>
        `;
        document.body.appendChild(alert);
        
        setTimeout(() => alert.remove(), 2000);
    },
    
    logAuthError(error) {
        console.error('[SuperDebug] Auth error:', error);
        
        let friendlyMessage = 'Ett okänt fel uppstod.';
        let technicalDetails = `Code: ${error.code}\nMessage: ${error.message}`;
        
        switch(error.code) {
            case 'auth/invalid-email':
                friendlyMessage = 'Ogiltig e-postadress.';
                break;
            case 'auth/user-disabled':
                friendlyMessage = 'Detta konto har inaktiverats.';
                break;
            case 'auth/user-not-found':
                friendlyMessage = 'Ingen användare hittades med denna e-post.';
                break;
            case 'auth/wrong-password':
                friendlyMessage = 'Fel lösenord.';
                break;
            case 'auth/invalid-credential':
                friendlyMessage = 'Felaktiga inloggningsuppgifter. Kontrollera email och lösenord.';
                break;
            case 'auth/too-many-requests':
                friendlyMessage = 'För många misslyckade försök. Försök igen om en stund.';
                break;
            case 'auth/network-request-failed':
                friendlyMessage = 'Nätverksfel. Kontrollera din internetanslutning.';
                break;
            case 'auth/popup-closed-by-user':
                friendlyMessage = 'Inloggningsfönstret stängdes.';
                break;
            case 'auth/unauthorized-domain':
                friendlyMessage = 'Denna domain är inte godkänd för Firebase Authentication.';
                technicalDetails += '\n\nFix: Lägg till din Netlify-domain i Firebase Console → Authentication → Settings → Authorized domains';
                break;
        }
        
        this.showBigError(
            '❌ Inloggning misslyckades',
            friendlyMessage,
            technicalDetails
        );
    }
};

// Initialize on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => SuperDebug.init());
} else {
    SuperDebug.init();
}

// Export for use in other files
window.SuperDebug = SuperDebug;
